from __main__ import app
from flask import Flask, render_template, url_for, session, request, redirect, sessions

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        return redirect(url_for('home'))
    return render_template('register.html')
